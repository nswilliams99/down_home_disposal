# Down Home Disposal - New Location Pages

## Files to Add

Copy these files to your Replit project:

```
app/
├── franklin-tn-garbage-pickup/
│   └── page.tsx          ← Copy from this folder
├── williamson-county-trash-pickup/
│   └── page.tsx          ← Copy from this folder
```

## Update sitemap.ts

Add these URLs to your `app/sitemap.ts` file:

```typescript
{
  url: 'https://www.downhomedisposal.com/franklin-tn-garbage-pickup',
  lastModified: new Date(),
  changeFrequency: 'monthly',
  priority: 0.8,
},
{
  url: 'https://www.downhomedisposal.com/williamson-county-trash-pickup',
  lastModified: new Date(),
  changeFrequency: 'monthly',
  priority: 0.8,
},
```

## Update llms.txt

Add to your `app/llms.txt/route.ts` (or public/llms.txt):

```
## Location Pages
- Franklin TN Garbage Pickup: https://www.downhomedisposal.com/franklin-tn-garbage-pickup
- Williamson County Trash Pickup: https://www.downhomedisposal.com/williamson-county-trash-pickup
```

## Update Service Areas Page

Add internal links from `/service-areas` to both new pages. In the Tuesday section:

```tsx
<a href="/franklin-tn-garbage-pickup">View Franklin Area Details →</a>
```

And consider adding a "County Pages" section:

```tsx
<a href="/williamson-county-trash-pickup">Williamson County Service Info →</a>
```

## Deploy Commands

```bash
git add .
git commit -m "Add Franklin TN and Williamson County location pages"
git push
```

## Keywords Targeted

| Page | Primary Keyword | Volume | KD | Current Position |
|------|----------------|--------|-----|------------------|
| /franklin-tn-garbage-pickup | franklin tn garbage pickup | 140 | 25 | 85 |
| /williamson-county-trash-pickup | williamson county trash pickup | 90 | 24 | Not ranking |

## Page Structure (Ed Sturm Compact Keywords Style)

Both pages follow the methodology:
- ~450 words each (not bloated)
- Bottom-of-funnel, purchase intent
- Clear differentiation (inside vs outside city limits)
- Service details upfront
- 4 FAQs with schema markup
- Strong CTAs
- No fluff, no "what is waste management" content

## Post-Deploy Checklist

1. [ ] Verify pages render at:
   - https://www.downhomedisposal.com/franklin-tn-garbage-pickup
   - https://www.downhomedisposal.com/williamson-county-trash-pickup
2. [ ] Check Schema Validator: https://validator.schema.org/
3. [ ] Submit to Google Search Console
4. [ ] Add internal links from Service Areas page
5. [ ] Update sitemap.xml
6. [ ] Update llms.txt
